configure({
  configs: [
    '../../../../config/bolt/demo.js'
  ]
});
