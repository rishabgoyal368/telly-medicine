configure({
  configs: [
    '../../../../../config/bolt/prod.theme.js'
  ]
});
